<footer class="footer bg-dark-footer relative text-gray-200">
    <div class="py-[30px] px-0 border-t border-slate-800">
        <div class="container text-center">
            <div class="grid grid-cols-1">
                <div class="text-center">
                    <p class="mb-0">
                        ©
                        <script>
                            document.write(new Date().getFullYear());
                        </script>
                        Humanities Journal with
                        <i class="mdi mdi-heart text-red-600"></i>
                        <a href="https://www.federalpolyilaro.edu.ng/" target="_blank" class="text-reset">The Federal
                            Polytechnic,
                            Ilaro</a>.
                    </p>
                </div>
            </div>
            <!--end grid-->
        </div>
        <!--end container-->
    </div>
</footer>
