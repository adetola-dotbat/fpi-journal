<div class="nk-footer">
    <div class="container-fluid">
        <div class="nk-footer-wrap">
            <div class="nk-footer-copyright"> &copy; 2023 <a href="#" target="_blank">..</a>
            </div>

        </div>
    </div>
</div>
